import xml.etree.ElementTree as ET
import os

XML_FILE = 'agenda.xml'
FIELDS = ['Nombre', 'Apellidos', 'Email', 'Telefono1', 'Telefono2', 'Direccion']

def mostrarMenu():
    opcion = 0
    while opcion > 3 or opcion < 1:        
        print("1. Guardar un nuevo contacto")
        print("2. Modificar un contacto")
        print("3. Eliminar un contacto")
        print("4. Buscar un contacto")
        print("5. Mostrar contactos")
        print("6. Salir del menú")
        opcion = int(input())
        if opcion == 1:
            crearContacto()
            opcion = 0
        elif opcion == 2:
            modificarContacto()
            opcion = 0
        elif opcion == 3:
            eliminarContacto()
            opcion = 0
        elif opcion == 4:
            buscarContacto()
            opcion = 0
        elif opcion == 6:
            break

def crearContacto():
    print("Inserte los datos de contacto")
    nombre = input("Nombre: ")
    apellido = input("Apellido: ")
    email = input("Email: ")
    telefono1 = input("Primer Telefono: ")
    telefono2 = input("Segundo Telefono: ")
    direccion = "Calle " + input("Direccion: ")
    if not os.path.exists(XML_FILE):
        root = ET.Element("Contactos")
    else:
        tree = ET.parse(XML_FILE)
        root = tree.getroot()
        contacto = ET.SubElement(root, "Contacto")
        for field, value in zip(FIELDS, [nombre, apellido, email, telefono1, telefono2, direccion]):
            ET.SubElement(contacto, field).text = value

        tree = ET.ElementTree(root)
        tree.write(XML_FILE)
        print("Contacto guardado correctamente.")

def modificarContacto():
    nombre = input("Ingrese el nombre del contacto a modificar: ")
    apellido = input("Ingrese los apellidos del contacto a modificar: ")
    encontrado = False
    tree = ET.parse(XML_FILE)
    root = tree.getroot()

    
    
    
mostrarMenu()